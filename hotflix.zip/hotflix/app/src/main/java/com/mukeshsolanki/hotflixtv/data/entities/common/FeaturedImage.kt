package com.mukeshsolanki.hotflixtv.data.entities.common

data class FeaturedImage(val url: String)