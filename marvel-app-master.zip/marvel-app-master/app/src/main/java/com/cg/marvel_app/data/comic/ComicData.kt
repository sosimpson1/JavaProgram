package com.cg.marvel_app.data.comic

data class ComicData(val results: List<ComicResult>)