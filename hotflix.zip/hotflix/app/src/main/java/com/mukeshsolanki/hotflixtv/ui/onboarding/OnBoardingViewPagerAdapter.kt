package com.mukeshsolanki.hotflixtv.ui.onboarding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.mukeshsolanki.hotflixtv.R
import kotlinx.android.synthetic.main.on_boarding_page.view.*

class OnBoardingViewPagerAdapter(
    private val viewPager: ViewPager2,
    private val listener: OnBoardingListener
) :
    RecyclerView.Adapter<OnBoardingViewPagerAdapter.OnBoardingPagerViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OnBoardingPagerViewHolder =
        OnBoardingPagerViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.on_boarding_page, parent, false)
        )

    //get the size of color array
    override fun getItemCount(): Int = 3

    //binding the screen with view
    override fun onBindViewHolder(holder: OnBoardingPagerViewHolder, position: Int) =
        holder.itemView.run {
            when (position) {
                0 -> {
                    onBoardingTitleTextView.text = context.getString(R.string.onboarding_title_one)
                    onBoardingSubTitleTextView.text =
                        context.getString(R.string.onboarding_subtitle_one)
                    onBoardingImageView.setImageResource(R.drawable.ic_onboarding_cloud)
                    onBoardingFinishButton.visibility = View.GONE
                    onBoardingNextButton.visibility = View.VISIBLE
                    onBoardingNextButton.setOnClickListener { viewPager.currentItem = 1 }
                }
                1 -> {
                    onBoardingTitleTextView.text = context.getString(R.string.onboarding_title_two)
                    onBoardingSubTitleTextView.text =
                        context.getString(R.string.onboarding_subtitle_two)
                    onBoardingImageView.setImageResource(R.drawable.ic_onboarding_movie)
                    onBoardingFinishButton.visibility = View.GONE
                    onBoardingNextButton.visibility = View.VISIBLE
                    onBoardingNextButton.setOnClickListener { viewPager.currentItem = 2 }
                }
                2 -> {
                    onBoardingTitleTextView.text =
                        context.getString(R.string.onboarding_title_three)
                    onBoardingSubTitleTextView.text =
                        context.getString(R.string.onboarding_subtitle_three)
                    onBoardingImageView.setImageResource(R.drawable.ic_onboarding_web_shows)
                    onBoardingFinishButton.visibility = View.VISIBLE
                    onBoardingNextButton.visibility = View.GONE
                    onBoardingFinishButton.setOnClickListener {
                        listener.onFinish()
                    }
                }
            }
        }

    inner class OnBoardingPagerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    interface OnBoardingListener {
        fun onFinish()
    }
}