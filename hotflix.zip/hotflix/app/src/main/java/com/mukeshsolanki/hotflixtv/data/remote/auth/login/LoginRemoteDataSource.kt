package com.mukeshsolanki.hotflixtv.data.remote.auth.login

import com.mukeshsolanki.hotflixtv.data.entities.auth.login.LoginRequest
import com.mukeshsolanki.hotflixtv.data.remote.BaseDataSource
import javax.inject.Inject

class LoginRemoteDataSource @Inject constructor(
    private val loginService: LoginService
) : BaseDataSource() {
    suspend fun login(loginRequest: LoginRequest) = getResult { loginService.login(loginRequest) }
}