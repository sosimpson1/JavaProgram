package com.mukeshsolanki.hotflixtv.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mukeshsolanki.hotflixtv.data.entities.movies.Movie

@Dao
interface MoviesDao {
    @Query("SELECT * FROM movies")
    fun getAllMovies(): LiveData<List<Movie>>

    @Query("SELECT * FROM movies WHERE `id` = :id")
    fun getMovie(id: String): LiveData<Movie>

    @Query("SELECT * FROM movies WHERE isFeatured = 1")
    fun getFeaturedMovies(): LiveData<List<Movie>>

    @Query("SELECT * FROM movies ORDER BY addedOn DESC")
    fun getNewMovies(): LiveData<List<Movie>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(movies: List<Movie>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(movie: Movie)
}
