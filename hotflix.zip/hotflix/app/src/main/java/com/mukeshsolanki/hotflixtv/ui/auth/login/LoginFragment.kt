package com.mukeshsolanki.hotflixtv.ui.auth.login

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import com.mukeshsolanki.hotflixtv.R
import com.mukeshsolanki.hotflixtv.databinding.LoginFragmentBinding
import com.mukeshsolanki.hotflixtv.extensions.launchActivity
import com.mukeshsolanki.hotflixtv.ui.main.MainActivity
import com.mukeshsolanki.hotflixtv.ui.widgets.ProgressBar
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.isLoggedIn
import com.mukeshsolanki.hotflixtv.utils.Resource
import com.mukeshsolanki.hotflixtv.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.login_fragment.*
import javax.inject.Inject

@AndroidEntryPoint
class LoginFragment : Fragment() {
    private var binding: LoginFragmentBinding by autoCleared()
    private val viewModel: LoginViewModel by viewModels()
    private lateinit var progressBar: ProgressBar

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = LoginFragmentBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setObservers()
        binding.registrationButton.setOnClickListener {
            findNavController().navigate(
                R.id.action_loginFragment_to_registrationFragment
            )
        }
    }

    private fun setObservers() {
        viewModel.performLogin.observe(viewLifecycleOwner, {
            if (it) {
                viewModel.login.observe(viewLifecycleOwner, { resource ->
                    when (resource.status) {
                        Resource.Status.SUCCESS -> {
                            if (sharedPreferences[isLoggedIn, false]!!) {
                                activity?.launchActivity<MainActivity>()
                                activity?.finish()
                                progressBar.dismiss()
                            }
                        }
                        Resource.Status.ERROR -> {
                            progressBar.dismiss()
                            Snackbar.make(loginRootView, resource.message!!, Snackbar.LENGTH_SHORT)
                                .show()
                        }
                        Resource.Status.LOADING -> {
                            progressBar = ProgressBar.show(
                                context, getString(R.string.progress_please_wait),
                                cancelListener = null
                            )
                        }
                    }
                })
            }
        })
    }
}