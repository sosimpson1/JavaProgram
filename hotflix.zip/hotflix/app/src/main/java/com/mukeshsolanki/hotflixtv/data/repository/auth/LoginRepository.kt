package com.mukeshsolanki.hotflixtv.data.repository.auth

import android.content.SharedPreferences
import android.text.TextUtils
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.data.entities.auth.login.LoginRequest
import com.mukeshsolanki.hotflixtv.data.remote.auth.login.LoginRemoteDataSource
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.isLoggedIn
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.jwt
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.set
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.user
import com.mukeshsolanki.hotflixtv.utils.performOperation
import javax.inject.Inject

class LoginRepository @Inject constructor(
    private val remoteDataSource: LoginRemoteDataSource,
    private val sharedPreferences: SharedPreferences,
    private val gson: Gson
) {
    fun login(loginRequest: LoginRequest) = performOperation(
        databaseQuery = { MutableLiveData<Boolean>(sharedPreferences[isLoggedIn, false]) },
        networkCall = { remoteDataSource.login(loginRequest) },
        saveCallResult = {
            if (TextUtils.isEmpty(it.jwt)) {
                sharedPreferences[isLoggedIn] = false
            } else {
                sharedPreferences[isLoggedIn] = true
                sharedPreferences[jwt] = it.jwt
                sharedPreferences[user] = gson.toJson(it.user)
            }
        }
    )
}