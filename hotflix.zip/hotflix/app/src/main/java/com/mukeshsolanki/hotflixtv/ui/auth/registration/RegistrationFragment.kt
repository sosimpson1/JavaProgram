package com.mukeshsolanki.hotflixtv.ui.auth.registration

import android.content.SharedPreferences
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.R
import com.mukeshsolanki.hotflixtv.data.entities.auth.User
import com.mukeshsolanki.hotflixtv.databinding.RegistrationFragmentBinding
import com.mukeshsolanki.hotflixtv.extensions.hideKeyboard
import com.mukeshsolanki.hotflixtv.ui.widgets.ProgressBar
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.Resource
import com.mukeshsolanki.hotflixtv.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.registration_fragment.*
import javax.inject.Inject

@AndroidEntryPoint
class RegistrationFragment : Fragment() {
    private var binding: RegistrationFragmentBinding by autoCleared()
    private val viewModel: RegistrationViewModel by viewModels()
    private lateinit var progressBar: ProgressBar

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var gson: Gson

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = RegistrationFragmentBinding.inflate(inflater, container, false)
        binding.viewModel = viewModel
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setObservers()
        setToolbar()
    }

    private fun setObservers() {
        viewModel.performRegistration.observe(viewLifecycleOwner, {
            if (it) {
                viewModel.register.observe(viewLifecycleOwner, { resource ->
                    when (resource.status) {
                        Resource.Status.SUCCESS -> {
                            if (!TextUtils.isEmpty(
                                    sharedPreferences[PreferencesUtil.user, gson.toJson(
                                        User("", "", "")
                                    )]
                                )
                            ) {
                                val user = gson.fromJson(
                                    sharedPreferences[PreferencesUtil.user, gson.toJson(
                                        User(
                                            "",
                                            "",
                                            ""
                                        )
                                    )], User::class.java
                                )
                                if (!TextUtils.isEmpty(user.id)) {
                                    progressBar.dismiss()
                                    findNavController().navigate(
                                        R.id.action_registrationFragment_to_thankYouFragment
                                    )
                                }
                            }
                        }
                        Resource.Status.ERROR -> {
                            progressBar.dismiss()
                            Snackbar.make(
                                registrationRootView,
                                resource.message!!,
                                Snackbar.LENGTH_SHORT
                            ).show()
                        }
                        Resource.Status.LOADING -> {
                            hideKeyboard()
                            progressBar = ProgressBar.show(
                                context, getString(R.string.progress_please_wait),
                                cancelListener = null
                            )
                        }
                    }
                })
            }
        })
    }

    private fun setToolbar() {
        (activity as AppCompatActivity?)?.setSupportActionBar(binding.registrationToolbar)
        (activity as AppCompatActivity?)?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        (activity as AppCompatActivity?)?.supportActionBar?.setDisplayShowHomeEnabled(true)
        binding.registrationToolbar.setNavigationOnClickListener {
            findNavController().popBackStack()
        }
    }
}