package com.mukeshsolanki.hotflixtv.data.local.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.data.entities.common.FeaturedImage

class FeaturedImageConverter {
    @TypeConverter
    fun toFeaturedImage(value: String): FeaturedImage {
        return Gson().fromJson(value, FeaturedImage::class.java)
    }

    @TypeConverter
    fun toString(featuredImage: FeaturedImage?): String {
        if (featuredImage == null) {
            return Gson().toJson(FeaturedImage(""))
        }
        return Gson().toJson(featuredImage)
    }
}