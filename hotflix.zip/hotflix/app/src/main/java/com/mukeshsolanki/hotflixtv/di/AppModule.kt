package com.mukeshsolanki.hotflixtv.di

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.mukeshsolanki.hotflixtv.BuildConfig
import com.mukeshsolanki.hotflixtv.data.local.AppDatabase
import com.mukeshsolanki.hotflixtv.data.local.InfoDao
import com.mukeshsolanki.hotflixtv.data.local.MoviesDao
import com.mukeshsolanki.hotflixtv.data.local.ShowsDao
import com.mukeshsolanki.hotflixtv.data.remote.HeaderInterceptor
import com.mukeshsolanki.hotflixtv.data.remote.auth.login.LoginRemoteDataSource
import com.mukeshsolanki.hotflixtv.data.remote.auth.login.LoginService
import com.mukeshsolanki.hotflixtv.data.remote.auth.registration.RegistrationRemoteDataSource
import com.mukeshsolanki.hotflixtv.data.remote.auth.registration.RegistrationService
import com.mukeshsolanki.hotflixtv.data.remote.info.InfoRemoteDataSource
import com.mukeshsolanki.hotflixtv.data.remote.info.InfoService
import com.mukeshsolanki.hotflixtv.data.remote.movies.MoviesRemoteDataSource
import com.mukeshsolanki.hotflixtv.data.remote.movies.MoviesService
import com.mukeshsolanki.hotflixtv.data.remote.shows.ShowsRemoteDataSource
import com.mukeshsolanki.hotflixtv.data.remote.shows.ShowsService
import com.mukeshsolanki.hotflixtv.data.repository.InfoRepository
import com.mukeshsolanki.hotflixtv.data.repository.MoviesRepository
import com.mukeshsolanki.hotflixtv.data.repository.ShowsRepository
import com.mukeshsolanki.hotflixtv.data.repository.auth.LoginRepository
import com.mukeshsolanki.hotflixtv.data.repository.auth.RegistrationRepository
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ApplicationComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Named
import javax.inject.Singleton


@Module
@InstallIn(ApplicationComponent::class)
object AppModule {

    @Provides
    @Named("UnAuthenticatedRetrofit")
    fun provideRetrofit(
        gson: Gson,
        @Named("UnAuthenticatedClient") okHttpClient: OkHttpClient
    ): Retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .client(okHttpClient)
        .build()

    @Provides
    @Named("AuthenticatedRetrofit")
    fun provideAuthenticatedRetrofit(
        gson: Gson,
        @Named("AuthenticatedClient") okHttpClient: OkHttpClient
    ): Retrofit =
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .build()

    @Provides
    @Named("UnAuthenticatedClient")
    fun provideOkHttp(): OkHttpClient {
        val interceptor = HttpLoggingInterceptor()
        interceptor.apply { interceptor.level = HttpLoggingInterceptor.Level.BODY }
        return OkHttpClient.Builder().addInterceptor(interceptor).build()
    }

    @Provides
    @Named("AuthenticatedClient")
    fun provideAuthenticatedOkHttp(headerInterceptor: HeaderInterceptor): OkHttpClient {
        val interceptor = HttpLoggingInterceptor()
        interceptor.apply { interceptor.level = HttpLoggingInterceptor.Level.BODY }
        return OkHttpClient.Builder().addInterceptor(interceptor).addInterceptor(headerInterceptor)
            .build()
    }

    @Provides
    fun provideHeaderInterceptor(sharedPreferences: SharedPreferences): HeaderInterceptor {
        return HeaderInterceptor(sharedPreferences)
    }


    @Provides
    fun provideGson(): Gson = GsonBuilder().create()

    @Singleton
    @Provides
    fun provideDatabase(@ApplicationContext appContext: Context) = AppDatabase.getDatabase(
        appContext
    )

    @Provides
    fun provideInfoService(@Named("UnAuthenticatedRetrofit") retrofit: Retrofit): InfoService =
        retrofit.create(InfoService::class.java)

    @Singleton
    @Provides
    fun provideInfoRemoteDataSource(infoService: InfoService) = InfoRemoteDataSource(infoService)

    @Singleton
    @Provides
    fun provideInfoDao(db: AppDatabase) = db.infoDao()

    @Singleton
    @Provides
    fun provideInfoRepository(
        remoteDataSource: InfoRemoteDataSource,
        localDataSource: InfoDao
    ) = InfoRepository(remoteDataSource, localDataSource)

    @Provides
    fun provideSharedPreferences(
        @ApplicationContext context: Context
    ): SharedPreferences {
        return PreferencesUtil.defaultPrefs(context)
    }

    @Singleton
    @Provides
    fun provideLoginRemoteDataSource(loginService: LoginService) =
        LoginRemoteDataSource(loginService)

    @Provides
    fun provideLoginService(@Named("UnAuthenticatedRetrofit") retrofit: Retrofit): LoginService =
        retrofit.create(LoginService::class.java)

    @Singleton
    @Provides
    fun provideLoginRepository(
        remoteDataSource: LoginRemoteDataSource,
        sharedPreferences: SharedPreferences, gson: Gson
    ) = LoginRepository(remoteDataSource, sharedPreferences, gson)

    @Singleton
    @Provides
    fun provideRegistrationRemoteDataSource(registrationService: RegistrationService) =
        RegistrationRemoteDataSource(registrationService)

    @Provides
    fun provideRegistrationService(@Named("UnAuthenticatedRetrofit") retrofit: Retrofit): RegistrationService =
        retrofit.create(RegistrationService::class.java)

    @Singleton
    @Provides
    fun provideRegistrationRepository(
        remoteDataSource: RegistrationRemoteDataSource,
        sharedPreferences: SharedPreferences,
        gson: Gson
    ) = RegistrationRepository(remoteDataSource, sharedPreferences, gson)

    @Provides
    fun provideMoviesService(@Named("AuthenticatedRetrofit") retrofit: Retrofit): MoviesService =
        retrofit.create(MoviesService::class.java)

    @Singleton
    @Provides
    fun provideMoviesRemoteDataSource(moviesService: MoviesService) =
        MoviesRemoteDataSource(moviesService)

    @Singleton
    @Provides
    fun provideMoviesDao(db: AppDatabase) = db.moviesDao()

    @Singleton
    @Provides
    fun provideMoviesRepository(
        remoteDataSource: MoviesRemoteDataSource,
        localDataSource: MoviesDao
    ) = MoviesRepository(remoteDataSource, localDataSource)

    @Provides
    fun provideShowsService(@Named("AuthenticatedRetrofit") retrofit: Retrofit): ShowsService =
        retrofit.create(ShowsService::class.java)

    @Singleton
    @Provides
    fun provideShowsRemoteDataSource(showsService: ShowsService) =
        ShowsRemoteDataSource(showsService)

    @Singleton
    @Provides
    fun provideShowsDao(db: AppDatabase) = db.showsDao()

    @Singleton
    @Provides
    fun provideShowsRepository(
        remoteDataSource: ShowsRemoteDataSource,
        localDataSource: ShowsDao
    ) = ShowsRepository(remoteDataSource, localDataSource)

}