package com.mukeshsolanki.hotflixtv.data.entities.common

data class Thumbnail(val url: String)