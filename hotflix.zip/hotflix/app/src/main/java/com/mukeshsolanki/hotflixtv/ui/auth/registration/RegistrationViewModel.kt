package com.mukeshsolanki.hotflixtv.ui.auth.registration

import android.text.TextUtils
import androidx.databinding.ObservableField
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mukeshsolanki.hotflixtv.data.entities.auth.registration.RegistrationRequest
import com.mukeshsolanki.hotflixtv.data.repository.auth.RegistrationRepository
import com.mukeshsolanki.hotflixtv.utils.Resource

class RegistrationViewModel @ViewModelInject constructor(
    val repository: RegistrationRepository
) : ViewModel() {
    val username: ObservableField<String> = ObservableField()
    val email: ObservableField<String> = ObservableField()
    val password: ObservableField<String> = ObservableField()
    val confirmPassword: ObservableField<String> = ObservableField()
    var register: LiveData<Resource<String>> = MutableLiveData()

    val performRegistration = MutableLiveData(false)

    fun register() {
        if (TextUtils.isEmpty(username.get())) {
            //TODO show Error
            return
        }
        if (TextUtils.isEmpty(email.get())) {
            //TODO show Error
            return
        }
        if (TextUtils.isEmpty(password.get())) {
            //TODO show Error
            return
        }
        if (TextUtils.isEmpty(confirmPassword.get())) {
            //TODO show Error
            return
        }
        if (!password.get().equals(confirmPassword.get())) {
            //TODO show Error
            return
        }
        register = repository.register(
            RegistrationRequest(
                username.get().toString(),
                email.get().toString(),
                password.get().toString()
            )
        )
        performRegistration.value = true
    }
}