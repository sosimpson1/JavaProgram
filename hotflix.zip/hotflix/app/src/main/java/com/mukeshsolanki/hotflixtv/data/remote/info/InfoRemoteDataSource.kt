package com.mukeshsolanki.hotflixtv.data.remote.info


import com.mukeshsolanki.hotflixtv.data.remote.BaseDataSource
import javax.inject.Inject

class InfoRemoteDataSource @Inject constructor(
    private val inforService: InfoService
) : BaseDataSource() {
    suspend fun getAllInfo() = getResult { inforService.getAllInfos() }
    suspend fun getInfo(infoKey: String) = getResult { inforService.getInfo(infoKey) }
}