package com.mukeshsolanki.hotflixtv.data.entities.auth.login

import com.mukeshsolanki.hotflixtv.data.entities.auth.User

data class LoginResponse(
    val jwt: String,
    val user: User
)