package com.mukeshsolanki.hotflixtv.data.repository

import com.mukeshsolanki.hotflixtv.data.local.MoviesDao
import com.mukeshsolanki.hotflixtv.data.remote.movies.MoviesRemoteDataSource
import com.mukeshsolanki.hotflixtv.utils.performOperation
import javax.inject.Inject

class MoviesRepository @Inject constructor(
    private val remoteDataSource: MoviesRemoteDataSource,
    private val localDataSource: MoviesDao
) {
    fun getMovie(id: String) = performOperation(
        databaseQuery = { localDataSource.getMovie(id) },
        networkCall = { remoteDataSource.getMovie(id) },
        saveCallResult = { localDataSource.insert(it) }
    )

    fun getAllMovies() = performOperation(
        databaseQuery = { localDataSource.getAllMovies() },
        networkCall = { remoteDataSource.getAllMovies() },
        saveCallResult = { localDataSource.insertAll(it) }
    )

    fun getNewMovies() = performOperation(
        databaseQuery = { localDataSource.getNewMovies() },
        networkCall = { remoteDataSource.getNewMovies() },
        saveCallResult = { localDataSource.insertAll(it) }
    )

    fun getFeaturedMovies() = performOperation(
        databaseQuery = { localDataSource.getFeaturedMovies() },
        networkCall = { remoteDataSource.getFeaturedMovies() },
        saveCallResult = { localDataSource.insertAll(it) }
    )
}