package com.cg.marvel_app.data.comic

data class ComicResponse(val data: ComicData)