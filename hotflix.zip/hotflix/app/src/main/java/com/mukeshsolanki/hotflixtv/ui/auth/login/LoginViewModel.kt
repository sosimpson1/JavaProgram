package com.mukeshsolanki.hotflixtv.ui.auth.login

import android.text.TextUtils
import androidx.databinding.ObservableField
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mukeshsolanki.hotflixtv.data.entities.auth.login.LoginRequest
import com.mukeshsolanki.hotflixtv.data.repository.auth.LoginRepository
import com.mukeshsolanki.hotflixtv.utils.Resource


class LoginViewModel @ViewModelInject constructor(
    val repository: LoginRepository
) : ViewModel() {
    val identifier: ObservableField<String> = ObservableField()
    val password: ObservableField<String> = ObservableField()
    var login: LiveData<Resource<Boolean>> = MutableLiveData()

    val performLogin = MutableLiveData(false)

    fun login() {
        if (TextUtils.isEmpty(identifier.get())) {
            //TODO show Error
            return
        }
        if (TextUtils.isEmpty(password.get())) {
            //TODO show Error
            return
        }
        login = repository.login(
            LoginRequest(
                identifier.get().toString(),
                password.get().toString()
            )
        )
        performLogin.value = true
    }
}