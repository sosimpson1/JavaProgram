package com.mukeshsolanki.hotflixtv.data.repository

import com.mukeshsolanki.hotflixtv.data.local.InfoDao
import com.mukeshsolanki.hotflixtv.data.remote.info.InfoRemoteDataSource
import com.mukeshsolanki.hotflixtv.utils.performOperation
import javax.inject.Inject

class InfoRepository @Inject constructor(
    private val remoteDataSource: InfoRemoteDataSource,
    private val localDataSource: InfoDao
) {
    fun getInfo(infoKey: String) = performOperation(
        databaseQuery = { localDataSource.getInfo(infoKey) },
        networkCall = { remoteDataSource.getInfo(infoKey) },
        saveCallResult = { localDataSource.insert(it) }
    )

    fun getAllInfo() = performOperation(
        databaseQuery = { localDataSource.getAllInfo() },
        networkCall = { remoteDataSource.getAllInfo() },
        saveCallResult = { localDataSource.insertAll(it) }
    )
}