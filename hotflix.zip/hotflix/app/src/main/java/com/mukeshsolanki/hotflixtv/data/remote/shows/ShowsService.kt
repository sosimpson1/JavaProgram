package com.mukeshsolanki.hotflixtv.data.remote.shows

import com.mukeshsolanki.hotflixtv.data.entities.shows.Show
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface ShowsService {
    @GET("shows")
    suspend fun getAllShows(): Response<List<Show>>

    @GET("shows?_sort=added_on:DESC")
    suspend fun getNewShows(): Response<List<Show>>

    @GET("shows/{id}")
    suspend fun getShow(@Path("id") id: String): Response<Show>
}