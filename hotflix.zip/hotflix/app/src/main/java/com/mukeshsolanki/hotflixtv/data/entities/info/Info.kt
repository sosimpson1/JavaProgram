package com.mukeshsolanki.hotflixtv.data.entities.info

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "infos")
data class Info(
    @PrimaryKey
    val key: String,
    val value: String
)