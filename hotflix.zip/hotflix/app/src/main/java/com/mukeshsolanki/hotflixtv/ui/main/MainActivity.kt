package com.mukeshsolanki.hotflixtv.ui.main

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.mukeshsolanki.hotflixtv.R
import com.mukeshsolanki.hotflixtv.databinding.ActivityMainBinding
import com.mukeshsolanki.hotflixtv.extensions.launchActivity
import com.mukeshsolanki.hotflixtv.ui.auth.AuthenticationActivity
import com.mukeshsolanki.hotflixtv.ui.onboarding.OnBoardingActivity
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.hasSeenOnBoarding
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.isLoggedIn
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkOnBoarding()
    }

    private fun checkOnBoarding() {
        val onBoardingPref = sharedPreferences[hasSeenOnBoarding, false]
        if (!onBoardingPref!!) {
            launchActivity<OnBoardingActivity>()
            finish()
        } else {
            checkLogin()
        }
    }

    private fun checkLogin() {
        val loginPref = sharedPreferences[isLoggedIn, false]
        if (!loginPref!!) {
            launchActivity<AuthenticationActivity>()
            finish()
        } else {
            setupUI()
        }
    }

    private fun setupUI() {
        val binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navHostFragment: NavHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController: NavController = navHostFragment.navController
        NavigationUI.setupWithNavController(binding.mainBottomNavigationView, navController)
    }
}