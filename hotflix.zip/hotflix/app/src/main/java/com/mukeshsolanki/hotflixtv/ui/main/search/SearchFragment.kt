package com.mukeshsolanki.hotflixtv.ui.main.search

import androidx.fragment.app.Fragment

class SearchFragment : Fragment()