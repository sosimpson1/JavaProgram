package com.mukeshsolanki.hotflixtv.ui.main.home

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.SnapHelper
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.data.entities.auth.User
import com.mukeshsolanki.hotflixtv.databinding.HomeFragmentBinding
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.user
import com.mukeshsolanki.hotflixtv.utils.Resource
import com.mukeshsolanki.hotflixtv.utils.autoCleared
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var binding: HomeFragmentBinding by autoCleared()
    private val viewModel: HomeViewModel by viewModels()

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    @Inject
    lateinit var gson: Gson

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = HomeFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = gson.fromJson(
            sharedPreferences[user, gson.toJson(User("", "", ""))],
            User::class.java
        ).username
        setFeaturedMoviesObserver()
        setNewMoviesObserver()
        setNewShowsObserver()
    }

    private fun setNewShowsObserver() {
        viewModel.newShows.observe(viewLifecycleOwner, {
            when (it.status) {
                Resource.Status.SUCCESS -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    val newShowsAdapter = it.data?.let { it1 -> NewShowsAdapter(it1) }
                    binding.newShowsRecyclerView.adapter = newShowsAdapter
                }
                Resource.Status.ERROR -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    Snackbar.make(requireView(), it.message.toString(), Snackbar.LENGTH_SHORT)
                        .show()
                }

                Resource.Status.LOADING -> {
                    binding.homeRefreshLayout.isRefreshing = true
                }
            }
        })
    }

    private fun setNewMoviesObserver() {
        viewModel.newMovies.observe(viewLifecycleOwner, {
            when (it.status) {
                Resource.Status.SUCCESS -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    val newMoviesAdapter = it.data?.let { it1 -> NewMoviesAdapter(it1) }
                    binding.newMoviesRecyclerView.adapter = newMoviesAdapter
                }
                Resource.Status.ERROR -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    Snackbar.make(requireView(), it.message.toString(), Snackbar.LENGTH_SHORT)
                        .show()
                }

                Resource.Status.LOADING -> {
                    binding.homeRefreshLayout.isRefreshing = true
                }
            }
        })
    }

    private fun setFeaturedMoviesObserver() {
        viewModel.featuredMovies.observe(viewLifecycleOwner, {
            when (it.status) {
                Resource.Status.SUCCESS -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    val carouselAdapter = it.data?.let { it1 -> CarouselAdapter(it1) }
                    val snapHelper: SnapHelper = PagerSnapHelper()
                    binding.carouselRecyclerView.onFlingListener = null
                    snapHelper.attachToRecyclerView(binding.carouselRecyclerView)
                    binding.carouselRecyclerView.adapter = carouselAdapter
                }
                Resource.Status.ERROR -> {
                    binding.homeRefreshLayout.isRefreshing = false
                    Snackbar.make(requireView(), it.message.toString(), Snackbar.LENGTH_SHORT)
                        .show()
                }

                Resource.Status.LOADING -> {
                    binding.homeRefreshLayout.isRefreshing = true
                }
            }
        })
    }
}