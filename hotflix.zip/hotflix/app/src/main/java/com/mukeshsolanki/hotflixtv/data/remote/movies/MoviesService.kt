package com.mukeshsolanki.hotflixtv.data.remote.movies

import com.mukeshsolanki.hotflixtv.data.entities.movies.Movie
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface MoviesService {
    @GET("movies")
    suspend fun getAllMovies(): Response<List<Movie>>

    @GET("movies?is_featured=true")
    suspend fun getFeaturedMovies(): Response<List<Movie>>

    @GET("movies?_sort=added_on:DESC")
    suspend fun getNewMovies(): Response<List<Movie>>

    @GET("movies/{id}")
    suspend fun getMovie(@Path("id") id: String): Response<Movie>
}