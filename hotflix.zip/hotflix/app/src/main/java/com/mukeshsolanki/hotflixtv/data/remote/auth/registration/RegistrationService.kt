package com.mukeshsolanki.hotflixtv.data.remote.auth.registration

import com.mukeshsolanki.hotflixtv.data.entities.auth.registration.RegistrationRequest
import com.mukeshsolanki.hotflixtv.data.entities.auth.registration.RegistrationResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface RegistrationService {
    @POST("auth/local/register")
    suspend fun register(@Body registrationRequest: RegistrationRequest): Response<RegistrationResponse>
}