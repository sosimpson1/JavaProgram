package com.mukeshsolanki.hotflixtv.ui.main.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mukeshsolanki.hotflixtv.data.entities.shows.Show
import com.mukeshsolanki.hotflixtv.databinding.NewShowItemBinding

class NewShowsAdapter(private val shows: List<Show>) :
    RecyclerView.Adapter<NewShowsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewShowsAdapter.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = NewShowItemBinding.inflate(inflater)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NewShowsAdapter.ViewHolder, position: Int) =
        holder.bind(shows[position])

    override fun getItemCount(): Int = shows.size

    inner class ViewHolder(val binding: NewShowItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(show: Show) {
            binding.show = show
            binding.executePendingBindings()
        }
    }
}