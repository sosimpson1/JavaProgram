package com.mukeshsolanki.hotflixtv.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mukeshsolanki.hotflixtv.data.entities.shows.Show

@Dao
interface ShowsDao {
    @Query("SELECT * FROM shows")
    fun getAllShows(): LiveData<List<Show>>

    @Query("SELECT * FROM shows WHERE `id` = :id")
    fun getShow(id: String): LiveData<Show>

    @Query("SELECT * FROM shows ORDER BY addedOn DESC")
    fun getNewShows(): LiveData<List<Show>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(shows: List<Show>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(shows: Show)
}
