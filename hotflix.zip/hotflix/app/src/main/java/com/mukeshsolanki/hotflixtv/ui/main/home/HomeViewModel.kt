package com.mukeshsolanki.hotflixtv.ui.main.home

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel
import com.mukeshsolanki.hotflixtv.data.repository.MoviesRepository
import com.mukeshsolanki.hotflixtv.data.repository.ShowsRepository

class HomeViewModel @ViewModelInject constructor(
    moviesRepository: MoviesRepository, showsRepository: ShowsRepository
) : ViewModel() {
    val featuredMovies = moviesRepository.getFeaturedMovies()
    val newMovies = moviesRepository.getNewMovies()
    val newShows = showsRepository.getNewShows()
}