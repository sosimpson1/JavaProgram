package com.cg.marvel_app.data.series

data class SeriesData(val results: List<SeriesResult>)