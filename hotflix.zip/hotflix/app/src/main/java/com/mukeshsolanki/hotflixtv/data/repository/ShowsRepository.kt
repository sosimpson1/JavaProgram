package com.mukeshsolanki.hotflixtv.data.repository

import com.mukeshsolanki.hotflixtv.data.local.ShowsDao
import com.mukeshsolanki.hotflixtv.data.remote.shows.ShowsRemoteDataSource
import com.mukeshsolanki.hotflixtv.utils.performOperation
import javax.inject.Inject

class ShowsRepository @Inject constructor(
    private val remoteDataSource: ShowsRemoteDataSource,
    private val localDataSource: ShowsDao
) {
    fun getShow(id: String) = performOperation(
        databaseQuery = { localDataSource.getShow(id) },
        networkCall = { remoteDataSource.getShow(id) },
        saveCallResult = { localDataSource.insert(it) }
    )

    fun getAllShows() = performOperation(
        databaseQuery = { localDataSource.getAllShows() },
        networkCall = { remoteDataSource.getAllShows() },
        saveCallResult = { localDataSource.insertAll(it) }
    )

    fun getNewShows() = performOperation(
        databaseQuery = { localDataSource.getNewShows() },
        networkCall = { remoteDataSource.getNewShows() },
        saveCallResult = { localDataSource.insertAll(it) }
    )
}