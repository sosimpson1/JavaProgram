package com.mukeshsolanki.hotflixtv.extensions

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.squareup.picasso.Picasso

@BindingAdapter("image")
fun ImageView.loadImage(url: String) {
    val placeHolderImage="https://ik.imagekit.io/hotflixtv/featured_image_placeholder_5c441f73f2_4f2wY8Dp9.png"
    if(url.isEmpty()){
        Picasso.get().load(placeHolderImage).into(this)
    }else{
        Picasso.get().load(url).into(this)
    }
}
