package com.mukeshsolanki.hotflixtv.ui.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mukeshsolanki.hotflixtv.databinding.ActivityAuthenticationBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AuthenticationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityAuthenticationBinding =
            ActivityAuthenticationBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}