package com.mukeshsolanki.hotflixtv.ui.main.settings

import androidx.fragment.app.Fragment

class SettingsFragment : Fragment()