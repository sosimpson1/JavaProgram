package com.mukeshsolanki.hotflixtv.data.repository.auth

import android.content.SharedPreferences
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.data.entities.auth.User
import com.mukeshsolanki.hotflixtv.data.entities.auth.registration.RegistrationRequest
import com.mukeshsolanki.hotflixtv.data.remote.auth.registration.RegistrationRemoteDataSource
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.get
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.set
import com.mukeshsolanki.hotflixtv.utils.performOperation
import javax.inject.Inject

class RegistrationRepository @Inject constructor(
    private val remoteDataSource: RegistrationRemoteDataSource,
    private val sharedPreferences: SharedPreferences,
    private val gson: Gson
) {
    fun register(registrationRequest: RegistrationRequest) = performOperation(
        databaseQuery = {
            MutableLiveData<String>(
                sharedPreferences[PreferencesUtil.user, gson.toJson(
                    User("", "", "")
                )]
            )
        },
        networkCall = { remoteDataSource.register(registrationRequest) },
        saveCallResult = {
            sharedPreferences[PreferencesUtil.user] = gson.toJson(it.user)
        }
    )
}