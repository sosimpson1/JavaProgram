package com.mukeshsolanki.hotflixtv.data.remote.shows

import com.mukeshsolanki.hotflixtv.data.remote.BaseDataSource
import javax.inject.Inject

class ShowsRemoteDataSource @Inject constructor(
    private val showsService: ShowsService
) : BaseDataSource() {
    suspend fun getAllShows() = getResult { showsService.getAllShows() }
    suspend fun getShow(id: String) = getResult { showsService.getShow(id) }
    suspend fun getNewShows() = getResult { showsService.getNewShows() }
}