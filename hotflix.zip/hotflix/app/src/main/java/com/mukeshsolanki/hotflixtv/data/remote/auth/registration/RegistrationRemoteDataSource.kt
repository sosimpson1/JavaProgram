package com.mukeshsolanki.hotflixtv.data.remote.auth.registration

import com.mukeshsolanki.hotflixtv.data.entities.auth.registration.RegistrationRequest
import com.mukeshsolanki.hotflixtv.data.remote.BaseDataSource
import javax.inject.Inject

class RegistrationRemoteDataSource @Inject constructor(
    private val registrationService: RegistrationService
) : BaseDataSource() {
    suspend fun register(registrationRequest: RegistrationRequest) =
        getResult { registrationService.register(registrationRequest) }
}