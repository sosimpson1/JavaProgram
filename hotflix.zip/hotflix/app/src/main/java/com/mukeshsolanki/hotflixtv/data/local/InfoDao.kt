package com.mukeshsolanki.hotflixtv.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mukeshsolanki.hotflixtv.data.entities.info.Info

@Dao
interface InfoDao {
    @Query("SELECT * FROM infos")
    fun getAllInfo(): LiveData<List<Info>>

    @Query("SELECT * FROM infos WHERE `key` = :infoKey")
    fun getInfo(infoKey: String): LiveData<Info>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(infos: List<Info>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(info: Info)
}
