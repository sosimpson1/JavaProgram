package com.cg.marvel_app.data.series

data class SeriesResponse(val data: SeriesData)