package com.mukeshsolanki.hotflixtv.ui.onboarding

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayoutMediator
import com.mukeshsolanki.hotflixtv.databinding.ActivityOnBoardingBinding
import com.mukeshsolanki.hotflixtv.extensions.launchActivity
import com.mukeshsolanki.hotflixtv.ui.main.MainActivity
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.hasSeenOnBoarding
import com.mukeshsolanki.hotflixtv.utils.PreferencesUtil.set
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_on_boarding.*
import javax.inject.Inject

@AndroidEntryPoint
class OnBoardingActivity : AppCompatActivity(), OnBoardingViewPagerAdapter.OnBoardingListener {

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivityOnBoardingBinding = ActivityOnBoardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        onBoardingViewPager.adapter = OnBoardingViewPagerAdapter(onBoardingViewPager, this)
        TabLayoutMediator(viewPagerIndicatorTabLayout, onBoardingViewPager) { _, _ -> }.attach()
    }

    override fun onFinish() {
        sharedPreferences[hasSeenOnBoarding] = true
        launchActivity<MainActivity>()
        finish()
    }
}