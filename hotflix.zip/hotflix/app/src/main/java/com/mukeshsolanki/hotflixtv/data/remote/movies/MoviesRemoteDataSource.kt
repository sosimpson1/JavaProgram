package com.mukeshsolanki.hotflixtv.data.remote.movies

import com.mukeshsolanki.hotflixtv.data.remote.BaseDataSource
import javax.inject.Inject

class MoviesRemoteDataSource @Inject constructor(
    private val moviesService: MoviesService
) : BaseDataSource() {
    suspend fun getAllMovies() = getResult { moviesService.getAllMovies() }
    suspend fun getMovie(id: String) = getResult { moviesService.getMovie(id) }
    suspend fun getFeaturedMovies() = getResult { moviesService.getFeaturedMovies() }
    suspend fun getNewMovies() = getResult { moviesService.getNewMovies() }
}