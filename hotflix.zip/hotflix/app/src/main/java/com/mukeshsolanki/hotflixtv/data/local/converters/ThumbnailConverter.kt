package com.mukeshsolanki.hotflixtv.data.local.converters

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.mukeshsolanki.hotflixtv.data.entities.common.Thumbnail

class ThumbnailConverter {
    @TypeConverter
    fun toThumbnail(value: String): Thumbnail {
        return Gson().fromJson(value, Thumbnail::class.java)
    }

    @TypeConverter
    fun toString(thumbnail: Thumbnail?): String {
        if (thumbnail == null) {
            return Gson().toJson(Thumbnail(""))
        }
        return Gson().toJson(thumbnail)
    }
}