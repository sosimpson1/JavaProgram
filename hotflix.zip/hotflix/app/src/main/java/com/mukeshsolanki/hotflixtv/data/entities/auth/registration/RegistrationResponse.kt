package com.mukeshsolanki.hotflixtv.data.entities.auth.registration

import com.mukeshsolanki.hotflixtv.data.entities.auth.User

data class RegistrationResponse(
    val user: User
)