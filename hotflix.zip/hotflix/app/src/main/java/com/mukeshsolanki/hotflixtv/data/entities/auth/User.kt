package com.mukeshsolanki.hotflixtv.data.entities.auth

data class User(
    val username: String,
    val email: String,
    val id: String
)