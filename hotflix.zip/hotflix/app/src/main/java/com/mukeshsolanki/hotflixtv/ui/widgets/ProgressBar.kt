package com.mukeshsolanki.hotflixtv.ui.widgets

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.drawable.AnimationDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.mukeshsolanki.hotflixtv.R
import kotlinx.android.synthetic.main.progress_bar.*

class ProgressBar : Dialog {
    constructor(context: Context?) : super(context!!)
    constructor(context: Context?, theme: Int) : super(context!!, theme)

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        val imageView =
            findViewById<View>(R.id.spinnerImageView) as ImageView
        val spinner = imageView.background as AnimationDrawable
        spinner.start()
    }

    fun setMessage(message: CharSequence?) {
        if (message != null && message.isNotEmpty()) {
            progressMessage.visibility = View.VISIBLE
            val txt = progressMessage as TextView
            txt.text = message
            txt.invalidate()
        }
    }

    companion object {
        fun show(
            context: Context?,
            message: CharSequence?,
            cancelable: Boolean = false,
            cancelListener: DialogInterface.OnCancelListener?
        ): ProgressBar {
            val dialog = ProgressBar(context, R.style.ProgressBar)
            dialog.setTitle("")
            dialog.setContentView(R.layout.progress_bar)
            if (message == null || message.isEmpty()) {
                dialog.progressMessage.visibility = View.GONE
            } else {
                val txt = dialog.progressMessage as TextView
                txt.text = message
            }
            dialog.setCancelable(cancelable)
            dialog.setOnCancelListener(cancelListener)
            dialog.window!!.attributes.gravity = Gravity.CENTER
            val lp = dialog.window!!.attributes
            lp.dimAmount = 0.2f
            dialog.window!!.attributes = lp
//            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            dialog.show()
            return dialog
        }
    }
}