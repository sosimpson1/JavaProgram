package com.mukeshsolanki.hotflixtv.data.entities.movies

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.SerializedName
import com.mukeshsolanki.hotflixtv.data.entities.common.FeaturedImage
import com.mukeshsolanki.hotflixtv.data.entities.common.Thumbnail
import com.mukeshsolanki.hotflixtv.data.local.converters.FeaturedImageConverter
import com.mukeshsolanki.hotflixtv.data.local.converters.ThumbnailConverter

@Entity(tableName = "movies")
data class Movie(
    @PrimaryKey
    val id: String,
    val genre: String,
    @SerializedName("released_on")
    val releasedOn: String,
    @SerializedName("video_url")
    val videoUrl: String,
    val title: String,
    val language: String,
    val runtime: String,
    val description: String,
    val rating: Int,
    @SerializedName("added_on")
    val addedOn: String,
    @SerializedName("featured_image")
    @TypeConverters(FeaturedImageConverter::class)
    val featuredImage: FeaturedImage?,
    @TypeConverters(ThumbnailConverter::class)
    val thumbnail: Thumbnail?,
    @SerializedName("is_featured")
    val isFeatured: Boolean
)