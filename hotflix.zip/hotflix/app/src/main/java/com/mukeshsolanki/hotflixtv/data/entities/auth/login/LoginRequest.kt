package com.mukeshsolanki.hotflixtv.data.entities.auth.login

data class LoginRequest(
    val identifier: String,
    val password: String
)