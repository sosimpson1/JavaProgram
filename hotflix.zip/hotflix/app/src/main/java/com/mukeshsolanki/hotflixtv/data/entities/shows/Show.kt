package com.mukeshsolanki.hotflixtv.data.entities.shows

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.SerializedName
import com.mukeshsolanki.hotflixtv.data.entities.common.FeaturedImage
import com.mukeshsolanki.hotflixtv.data.entities.common.Thumbnail
import com.mukeshsolanki.hotflixtv.data.local.converters.FeaturedImageConverter
import com.mukeshsolanki.hotflixtv.data.local.converters.ThumbnailConverter

@Entity(tableName = "shows")
data class Show(
    @PrimaryKey
    val id: String,
    @SerializedName("released_on")
    val releasedOn: String,
    val title: String,
    val language: String,
    val description: String,
    val rating: Int,
    @SerializedName("added_on")
    val addedOn: String,
    @SerializedName("featured_image")
    @TypeConverters(FeaturedImageConverter::class)
    val featuredImage: FeaturedImage?,
    @TypeConverters(ThumbnailConverter::class)
    val thumbnail: Thumbnail?
)