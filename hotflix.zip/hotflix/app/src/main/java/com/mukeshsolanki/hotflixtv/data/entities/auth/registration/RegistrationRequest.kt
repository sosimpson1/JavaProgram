package com.mukeshsolanki.hotflixtv.data.entities.auth.registration

data class RegistrationRequest(
    val username: String,
    val email: String,
    val password: String
)