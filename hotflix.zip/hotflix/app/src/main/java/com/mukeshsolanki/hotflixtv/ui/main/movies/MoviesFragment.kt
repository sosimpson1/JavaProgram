package com.mukeshsolanki.hotflixtv.ui.main.movies

import androidx.fragment.app.Fragment

class MoviesFragment : Fragment()