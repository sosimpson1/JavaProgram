package com.mukeshsolanki.hotflixtv.data.remote.info

import com.mukeshsolanki.hotflixtv.data.entities.info.Info
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface InfoService {
    @GET("infos")
    suspend fun getAllInfos(): Response<List<Info>>

    @GET("infos/{key}")
    suspend fun getInfo(@Path("key") infoKey: String): Response<Info>
}