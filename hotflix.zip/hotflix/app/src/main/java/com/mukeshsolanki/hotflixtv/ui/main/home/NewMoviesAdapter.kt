package com.mukeshsolanki.hotflixtv.ui.main.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mukeshsolanki.hotflixtv.data.entities.movies.Movie
import com.mukeshsolanki.hotflixtv.databinding.NewMovieItemBinding

class NewMoviesAdapter(private val movies: List<Movie>) :
    RecyclerView.Adapter<NewMoviesAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewMoviesAdapter.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = NewMovieItemBinding.inflate(inflater)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NewMoviesAdapter.ViewHolder, position: Int) =
        holder.bind(movies[position])

    override fun getItemCount(): Int = movies.size

    inner class ViewHolder(val binding: NewMovieItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(movie: Movie) {
            binding.movie = movie
            binding.executePendingBindings()
        }
    }
}